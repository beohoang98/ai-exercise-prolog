Test questions was writed in Prolog in `test-script.pl`
Run test script by bash or shell

```
swipl -s test-script.pl
```

Result will be printed in `test-output.txt`