## Recreate a program that can read Prolog clause and answer query

**Language**: Python